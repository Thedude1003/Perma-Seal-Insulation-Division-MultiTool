# Perma-Seal Field Reference Calculators

Attic insulation, crawl space, and radiant barrier measurement/estimating tools for Perma-Seal reps.
Single self-contained `index.html` — no build step, no dependencies.

## Run locally
Just open `index.html` in a browser.

## Publish with GitHub Pages
1. Push this repo to GitHub (see steps below).
2. On GitHub: Settings → Pages → Source → select the `main` branch and `/ (root)` folder → Save.
3. GitHub will publish it at `https://<your-username>.github.io/<repo-name>/` within a minute or two.

## Update the tool later
Edit `index.html` directly (it's plain HTML/CSS/JS), commit, and push — Pages redeploys automatically.
